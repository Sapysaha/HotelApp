<!DOCTYPE html>
<html>
    <head>
        <title>Movie App</title>
        <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
        <link rel = "stylesheet" type = "text/css" href = "../public/CSS/style.css"/>
    </head>
    <body>