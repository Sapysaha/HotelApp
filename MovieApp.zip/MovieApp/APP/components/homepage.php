<?php
    require_once("../../API/Includes/connection.php");
    require_once("../../API/Includes/session.php");
    require_once("./partials/header.php");
    require_once("./partials/nav.php");
    // echo $_SESSION['username'];
?>
    <div class = "homepage">
        <h1>This is the homepage</h1>
    </div>
<?php
    require_once("./partials/footer.php");
?>